import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.Encoders
import org.apache.spark.sql.types._
import java.io._

object Main {

  def main(args: Array[String]): Unit = {

    println("-------------------Hello, Scala!-------------------")

    val sparkConf = new SparkConf()
      .setMaster("local[*]")
      .setAppName("Counting words")

    val sc = new SparkContext(sparkConf)

    // for reduce logging output
    sc.setLogLevel("ERROR")

    //creat SparkSession
    val spark = SparkSession.builder()
      .appName("Simple Search Engine")
      .master("local[2]")
      .config("spark.mongodb.input.uri", "mongodb://localhost:27017/SearchEngineDb.InvertIndex")
      .config("spark.mongodb.output.uri", "mongodb://localhost:27017/SearchEngineDb.InvertIndex")
      .getOrCreate()

    val mongodb_host_name = "localhost"
    val mongodb_port_no = "27017"
    val mongodb_database_name = "SearchEngineDb"
    val mongodb_collection_name = "InvertIndex"

    val spark_mongodb_output_uri = "mongodb://" + mongodb_host_name + ":" + mongodb_port_no + "/" + mongodb_database_name + "." + mongodb_collection_name
    println("Printing spark_mongodb_output_uri: " + spark_mongodb_output_uri)

    val invertIndex_df = spark.read
      .format("mongo")
      .schema(StructType(
        StructField("word", StringType, true) ::
          StructField("count", LongType, true) ::
          StructField("document_list", ArrayType(StringType), true) :: Nil
      ))
      .option("uri", spark_mongodb_output_uri)
      .option("database", mongodb_database_name)
      .option("collection", mongodb_collection_name)
      .load()

    //********************************************** Word Count ****************************************************//

    println("------------------Welcome to our system!-------------------")

    /*rddContent:RDDTuple = (
      ("data/doc1.txt", "content of doc1"),
      ("data/doc2.txt", "content of doc2"),
      ("data/doc3.txt", "content of doc3")....
    )*/
    //wholeTextFiles("args(0),args(1),args(2),args(3),...")
    val rddContent = sc.wholeTextFiles(args.mkString(","))

    // invertedIndex:RDDTuple =(word, (number of documents where the word appeared, [doc1, doc2, doc3...]))||
    val invertedIndex = rddContent
      //(extension,content) => function
      .flatMap { case (filename, content) =>
        //data/doc n.txt
        val documentName = filename.split("/").last //Extract name doc from path
        // RDD:[Each word of each document associated with its document name| (word, documentName) |..|...]
        content.split("\\s+").map(word => (word, documentName))
      }
      //Remove duplicates of a word in a single document so that each word is associated with the document only once
      .distinct()
      //(word , [doc1, doc2, doc3...])
      .groupByKey() // Combine the same key into a single tuple and sum their values in array
      //RDD:(word, (number of documents where the word appeared, [doc1, doc2, doc3...]))||
      .mapValues(docs => (docs.size, docs.toList.sorted))


    val results = invertedIndex
      // take keys and sort them in alphabetical order
      .sortByKey(ascending = false)
      .collect()

    println("             ### Inverted Index Results ###")
    println()
    println("The following represents the inverted index of words extracted from a collection of documents")
    println()
    println("| ***Word*** | **Document Count** | **Document Names**           |")
    println("|------------|--------------------|------------------------------|")
    results.foreach { case (word, (count, docs)) =>
      //print the tuple   (x._1 "word"  ,  x._2 "(count, docs)")
      println(f"| $word%-10s | $count%-18d | ${docs.mkString(", ")} |")
    }
    println(s"Number of files passed: ${args.length}")


    // jsonRDD: RDD that I send to the database
    val jsonRDD: RDD[String] = invertedIndex
      // Sort the RDD by keys (words) in alphabetical order
      .sortByKey()
      // map each (word, (count, docs)) pair to a JSON string representation
      .map { case (word, (count, docs)) =>
        s"""{
                  "word": "$word",
                  "count": $count,
                  "document_list": ["${docs.mkString("\", \"")}"] // List of documents containing the word, formatted as a JSON array
                }"""
      }

    //*****wholeInvertedIndex.txt*****//
    //// Now, after creating the RDD JSON, each object will be taken and put in "wholeInvertedIndex.txt" text file

    //outputFile = name of the file to be written to
    val outputFile = "wholeInvertedIndex.txt"
    // PrintWriter() is class for writing character files
    // Create a new PrintWriter instance for writing to the specified output file
    val writer = new PrintWriter(new File(outputFile))

    val tableHeader =
      """
          ------------------Welcome to our system!-------------------
                       ### Inverted Index Results ###

          The following represents the inverted index of words extracted from a collection of documents

          | ***Word*** | **Document Count** | **Document Names**           |
          |------------|--------------------|------------------------------|
          """
    //Write to the file the text in the "tableHeader" variable
    writer.write(tableHeader)

    val tableRows = invertedIndex
      // Sort the RDD by keys (words) in alphabetical order
      .sortByKey()
      // map each (word, (count, docs)) pair to a JSON string representation
      .map { case (word, (count, docs)) =>
        //print the tuple   (x._1 "word"  ,  x._2 "(count, docs)")
        f"| $word%-10s | $count%-18d | ${docs.mkString(", ")}%-30s |"
      }
    // Each element of the array is a formatted string representing a row in the inverted index table
    tableRows.collect().foreach { line =>
      writer.write(line + "\n")
    }

    writer.close()

    println(s"Data has been written to $outputFile")


    //***** DB *****//
    println("------------------Welcome to our database!-------------------")
    println("Number of records in InvertIndex before inserting JSON document data: " + invertIndex_df.count())
    println("Contents of InvertIndex:")
    invertIndex_df.show(truncate = false)


        val jsonDS: Dataset[String] = spark.createDataset(jsonRDD.collect())(Encoders.STRING)
        val new_invertIndex_df = spark.read.json(jsonDS)

        new_invertIndex_df.write
          .format("mongo")
          .option("uri", spark_mongodb_output_uri)
          .option("database", mongodb_database_name)
          .option("collection", mongodb_collection_name)
          .mode("append")
          .save()

        val updated_invertIndex_df = spark.read
          .format("mongo")
          .option("uri", spark_mongodb_output_uri)
          .option("database", mongodb_database_name)
          .option("collection", mongodb_collection_name)
          .load()


        println("Updated Contents of InvertIndex:")
        updated_invertIndex_df.show(truncate = false)
        println("Number of records in InvertIndex: " + updated_invertIndex_df.count())


  }

}



